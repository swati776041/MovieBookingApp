import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addmovie',
  templateUrl: './addmovie.component.html',
  styleUrls: ['./addmovie.component.css']
})
export class AddmovieComponent implements OnInit {
  ticketsStatus !: string ;

 public movies = {
    movieName :'',
    theatreName :'',
    noOfTicketsAvailable :0,
    ticketsStatus :'',
    bannerimg: ''
    
  }

  messages : string =""

  constructor(private movieService:UserService,private router:Router) { }

  addMovie(){
    let flag = false;
      if(this.movies.movieName == '' || this.movies.movieName == null){
        Swal.fire('','Movie Name is required !','info');
        flag = true;
          return;
      }
      if(this.movies.theatreName == '' || this.movies.theatreName == null){
        Swal.fire('','Theatre Name is required','info');
        flag = true;
        return;
      }
      if(this.movies.bannerimg == '' || this.movies.bannerimg == null){
        Swal.fire('','Provide the Banner Image!','info');
        flag = true;
        return;
      }
      if(this.movies.noOfTicketsAvailable == null){
        Swal.fire('','NoOfTicketsAvailable is required !','info');
        flag = true;
        return;
      }
      if(this.ticketsStatus == '' || this.ticketsStatus == null){
        Swal.fire('','Please Select TicketStatus!','info');
        flag = true;
        return;
      }
      
    this.movies.ticketsStatus = this.ticketsStatus
    this.movieService.addMovie(this.movies).subscribe(
      (data: any)=>{
        Swal.fire('Movie Added Successfully',data,'success');
        console.log(data);
        this.router.navigate(['/api/v1.0/moviebooking/all']);
      },
      (error: any)=>{
        Swal.fire('Movie is already present',error,'error');
        console.log(JSON.stringify(error));
        this.router.navigate(['/api/v1.0/moviebooking/addMovie']);
      }
    );
    console.log(this.movies)
  }



  ngOnInit(): void {
    
  }

}
