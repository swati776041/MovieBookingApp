import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';
import { UserService } from 'src/app/services/user.service';
import Swal from 'sweetalert2';
import { PageEvent } from '@angular/material/paginator';

@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css']
})
export class MoviesComponent {
  constructor(private userService:UserService,private router:Router,public loginService:LoginService){}
  movies : {
    position: number,
    movieName: string,
    theaterName: string,
    ticketStatus: string,
    noOfTicketsAvailable:number,
    bannerimg: string
    }[] = [];
   
      // Pagination properties
  totalItems: number = 0;
  itemsPerPage: number = 3;
  // pageSizeOptions: number[] = [3,5, 10, 25, 50];
  currentPageIndex: number = 0;

  ngOnInit(): void {
    this.getMoviesData();
  }

  onPageChange(event: PageEvent): void {
    this.currentPageIndex = event.pageIndex;
    this.itemsPerPage = event.pageSize;
    this.getMoviesData();
  }

  getMoviesData(): void {
    this.userService.allMovies().subscribe(
      (data: any) => {
        let count = data.length;
        this.totalItems = count;
        this.movies = [];
        let i = this.currentPageIndex * this.itemsPerPage + 1;
        while (i <= count && i < (this.currentPageIndex + 1) * this.itemsPerPage + 1) {
          this.movies.push({
            position: i, movieName: data[i - 1].movieName, theaterName: data[i - 1].theatreName,
            ticketStatus: data[i - 1].ticketsStatus, noOfTicketsAvailable: data[i - 1].noOfTicketsAvailable, bannerimg: data[i - 1].bannerimg
          });
          i++;
        }
      },
      (error) => {
        console.log("from movies Component :" + error);
      }
    );
  }
  onClickBuyTicket(value:any){
    console.log("Buying Ticket "+value);
    let flag = false;
    this.movies.forEach(function (movie){
      if(value == movie.movieName && movie.ticketStatus == "SOLD OUT"){
        flag = true;
        Swal.fire('Cannot Book','This Movie is Sold Out','info');
      }
    })
    if(!flag){
      localStorage.setItem('movieToBook',value);
      this.router.navigate(['/api/v1.0/moviebooking/add'])
    }
  }
}
